# JAY MATAJI TRUCK BUY SELL

Android Kotlin + Jetpack Compose MVP.

## Current features
- Truck listing home screen
- Search by brand/model and location
- Truck detail page
- Up to 10 photo selection per listing
- Admin/seller dashboard
- Add, delete, and Available/Sold toggle
- Local persistence using SharedPreferences
- Call and WhatsApp buttons

## Open/build
1. Open this folder in Android Studio.
2. Let Gradle sync.
3. Run on an Android 8.0+ device/emulator.
4. Build > Build Bundle(s) / APK(s) > Build APK(s).

## Before real launch
Replace the demo phone/WhatsApp number in MainActivity.kt.
For a production marketplace, connect Firebase:
- Firebase Authentication for admin login
- Cloud Firestore for truck records
- Firebase Storage for photos
- Security Rules so only authenticated admins can add/edit/delete listings

The current version intentionally uses local storage so the project can be opened and tested without a Firebase project or google-services.json.

## Share feature
Every truck detail page has a **SHARE** button. It opens the Android share sheet with the truck's details and a unique Truck ID.

For a true clickable URL that opens the exact listing on another phone, the production version should connect Firebase/Firestore and a public app-link domain. The current offline MVP shares the listing details as text.
