package com.jaymataji.truckbuysell

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavHostController
import androidx.navigation.compose.*
import coil.compose.AsyncImage
import org.json.JSONArray
import org.json.JSONObject
import java.text.NumberFormat
import java.util.Locale

data class Truck(
    val id: Long,
    val brand: String,
    val model: String,
    val year: String,
    val km: String,
    val fuel: String,
    val price: Long,
    val location: String,
    val description: String,
    val photoUris: List<String> = emptyList(),
    val sold: Boolean = false
)

class TruckRepository(private val context: Context) {
    private val prefs = context.getSharedPreferences("trucks", Context.MODE_PRIVATE)

    fun load(): MutableList<Truck> {
        val raw = prefs.getString("data", null) ?: return demoTrucks().toMutableList()
        return try {
            val arr = JSONArray(raw)
            MutableList(arr.length()) { i ->
                val o = arr.getJSONObject(i)
                Truck(
                    o.getLong("id"), o.getString("brand"), o.getString("model"),
                    o.getString("year"), o.getString("km"), o.getString("fuel"),
                    o.getLong("price"), o.getString("location"), o.getString("description"),
                    List(o.optJSONArray("photos")?.length() ?: 0) { j ->
                        o.getJSONArray("photos").getString(j)
                    },
                    o.optBoolean("sold", false)
                )
            }
        } catch (_: Exception) {
            demoTrucks().toMutableList()
        }
    }

    fun save(list: List<Truck>) {
        val arr = JSONArray()
        list.forEach { t ->
            arr.put(JSONObject().apply {
                put("id", t.id); put("brand", t.brand); put("model", t.model)
                put("year", t.year); put("km", t.km); put("fuel", t.fuel)
                put("price", t.price); put("location", t.location)
                put("description", t.description); put("sold", t.sold)
                put("photos", JSONArray(t.photoUris))
            })
        }
        prefs.edit().putString("data", arr.toString()).apply()
    }

    private fun demoTrucks() = listOf(
        Truck(1, "TATA", "1612", "2022", "85000", "Diesel", 1850000,
            "Vadodara, Gujarat", "Well maintained truck in good condition."),
        Truck(2, "Ashok Leyland", "2518", "2021", "92000", "Diesel", 1725000,
            "Ahmedabad, Gujarat", "Single owner, good tyres."),
        Truck(3, "BharatBenz", "2823", "2020", "110000", "Diesel", 1975000,
            "Surat, Gujarat", "Ready for work.")
    )
}

fun money(v: Long): String =
    NumberFormat.getCurrencyInstance(Locale("en", "IN")).apply {
        maximumFractionDigits = 0
    }.format(v).replace("₹", "₹")

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { TruckApp(this) }
    }
}

@Composable
fun TruckApp(context: Context) {
    val repo = remember { TruckRepository(context) }
    var trucks by remember { mutableStateOf(repo.load()) }

    fun update(newList: MutableList<Truck>) {
        trucks = newList
        repo.save(newList)
    }

    MaterialTheme(
        colorScheme = lightColorScheme(
            primary = Color(0xFFE11D16),
            secondary = Color(0xFF0B2A4A),
            background = Color(0xFFF7F7F7)
        )
    ) {
        val nav = rememberNavController()
        NavHost(navController = nav, startDestination = "home") {
            composable("home") {
                HomeScreen(trucks, nav)
            }
            composable("search") {
                SearchScreen(trucks, nav)
            }
            composable("truck/{id}") { back ->
                val id = back.arguments?.getString("id")?.toLongOrNull()
                trucks.firstOrNull { it.id == id }?.let { TruckDetails(it, nav, context) }
            }
            composable("admin") {
                AdminScreen(trucks, nav, ::update)
            }
            composable("add") {
                AddTruckScreen(nav) { truck ->
                    val next = (trucks.maxOfOrNull { it.id } ?: 0) + 1
                    update((trucks + truck.copy(id = next)).toMutableList())
                    nav.popBackStack()
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AppTopBar(title: String, nav: NavHostController, showBack: Boolean = false) {
    TopAppBar(
        title = {
            Column {
                Text("JAY MATAJI", fontWeight = FontWeight.Bold, fontSize = 20.sp)
                Text(title, fontSize = 11.sp)
            }
        },
        navigationIcon = {
            if (showBack) IconButton({ nav.popBackStack() }) {
                Icon(Icons.Default.ArrowBack, null)
            } else Icon(Icons.Default.LocalShipping, null)
        },
        colors = TopAppBarDefaults.topAppBarColors(
            containerColor = Color(0xFFE11D16),
            titleContentColor = Color.White,
            navigationIconContentColor = Color.White
        )
    )
}

@Composable
fun HomeScreen(trucks: List<Truck>, nav: NavHostController) {
    Scaffold(
        topBar = { AppTopBar("TRUCK BUY SELL", nav) },
        floatingActionButton = {
            FloatingActionButton(onClick = { nav.navigate("admin") }) {
                Icon(Icons.Default.AdminPanelSettings, "Admin")
            }
        }
    ) { pad ->
        LazyColumn(
            modifier = Modifier.padding(pad).padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            item {
                Text("सही ट्रक – सही कीमत पर", fontSize = 22.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(6.dp))
                OutlinedButton(onClick = { nav.navigate("search") }) {
                    Icon(Icons.Default.Search, null)
                    Spacer(Modifier.width(6.dp))
                    Text("Search & Filter Trucks")
                }
                Spacer(Modifier.height(10.dp))
                Text("Available Trucks", fontSize = 19.sp, fontWeight = FontWeight.Bold)
            }
            items(trucks.filter { !it.sold }) { truck ->
                TruckCard(truck) { nav.navigate("truck/${truck.id}") }
            }
        }
    }
}

@Composable
fun TruckCard(truck: Truck, onClick: () -> Unit) {
    Card(
        modifier = Modifier.fillMaxWidth().clickable(onClick = onClick),
        shape = RoundedCornerShape(14.dp)
    ) {
        Row(Modifier.padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
            if (truck.photoUris.isNotEmpty()) {
                AsyncImage(
                    model = Uri.parse(truck.photoUris.first()),
                    contentDescription = null,
                    modifier = Modifier.size(105.dp).clip(RoundedCornerShape(10.dp)),
                    contentScale = ContentScale.Crop
                )
            } else {
                Box(
                    Modifier.size(105.dp).clip(RoundedCornerShape(10.dp))
                        .background(Color(0xFFEAEAEA)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(Icons.Default.LocalShipping, null, tint = Color(0xFF0B2A4A),
                        modifier = Modifier.size(45.dp))
                }
            }
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text("${truck.brand} ${truck.model}", fontWeight = FontWeight.Bold)
                Text("${truck.year} • ${truck.km} KM • ${truck.fuel}", fontSize = 13.sp)
                Text(truck.location, fontSize = 13.sp)
                Text(money(truck.price), color = Color(0xFFE11D16),
                    fontWeight = FontWeight.Bold, fontSize = 18.sp)
            }
        }
    }
}

@Composable
fun SearchScreen(trucks: List<Truck>, nav: NavHostController) {
    var query by remember { mutableStateOf("") }
    var location by remember { mutableStateOf("") }

    val filtered = trucks.filter {
        !it.sold &&
            ("${it.brand} ${it.model}".contains(query, true)) &&
            it.location.contains(location, true)
    }

    Scaffold(topBar = { AppTopBar("Search / Filter", nav, true) }) { pad ->
        Column(Modifier.padding(pad).padding(12.dp)) {
            OutlinedTextField(query, { query = it }, Modifier.fillMaxWidth(),
                label = { Text("Brand / Model") }, leadingIcon = {
                    Icon(Icons.Default.Search, null)
                })
            Spacer(Modifier.height(8.dp))
            OutlinedTextField(location, { location = it }, Modifier.fillMaxWidth(),
                label = { Text("Location") })
            Spacer(Modifier.height(12.dp))
            Text("${filtered.size} trucks found", fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(8.dp))
            LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                items(filtered) { t -> TruckCard(t) { nav.navigate("truck/${t.id}") } }
            }
        }
    }
}

@Composable
fun TruckDetails(truck: Truck, nav: NavHostController, context: Context) {
    Scaffold(topBar = { AppTopBar("Truck Details", nav, true) }) { pad ->
        LazyColumn(Modifier.padding(pad).padding(12.dp)) {
            item {
                if (truck.photoUris.isNotEmpty()) {
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        items(truck.photoUris) { uri ->
                            AsyncImage(Uri.parse(uri), null,
                                Modifier.size(300.dp, 220.dp).clip(RoundedCornerShape(14.dp)),
                                contentScale = ContentScale.Crop)
                        }
                    }
                } else {
                    Box(Modifier.fillMaxWidth().height(220.dp)
                        .background(Color(0xFFEAEAEA)), contentAlignment = Alignment.Center) {
                        Icon(Icons.Default.LocalShipping, null, Modifier.size(90.dp))
                    }
                }
                Spacer(Modifier.height(14.dp))
                Text("${truck.brand} ${truck.model}", fontSize = 25.sp, fontWeight = FontWeight.Bold)
                Text(money(truck.price), fontSize = 24.sp,
                    color = Color(0xFFE11D16), fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(12.dp))
                Detail("Year", truck.year)
                Detail("KM Driven", "${truck.km} KM")
                Detail("Fuel", truck.fuel)
                Detail("Location", truck.location)
                Spacer(Modifier.height(10.dp))
                Text(truck.description)
                Spacer(Modifier.height(18.dp))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Button(Modifier.weight(1f), onClick = {
                        // Replace with your real seller number.
                        val intent = Intent(Intent.ACTION_DIAL, Uri.parse("tel:9999999999"))
                        context.startActivity(intent)
                    }) {
                        Icon(Icons.Default.Call, null); Spacer(Modifier.width(3.dp)); Text("CALL")
                    }
                    Button(Modifier.weight(1f), onClick = {
                        // Replace with your WhatsApp number in international format.
                        val url = Uri.parse("https://wa.me/919999999999")
                        context.startActivity(Intent(Intent.ACTION_VIEW, url))
                    }) {
                        Icon(Icons.Default.Chat, null); Spacer(Modifier.width(3.dp)); Text("WHATSAPP")
                    }
                    OutlinedButton(Modifier.weight(1f), onClick = {
                        val shareText = """
                            🚛 JAY MATAJI TRUCK BUY SELL

                            ${truck.brand} ${truck.model}
                            Year: ${truck.year}
                            KM: ${truck.km}
                            Fuel: ${truck.fuel}
                            Price: ${money(truck.price)}
                            Location: ${truck.location}

                            ${truck.description}

                            Truck ID: ${truck.id}
                            Contact: 9999999999
                        """.trimIndent()
                        val intent = Intent(Intent.ACTION_SEND).apply {
                            type = "text/plain"
                            putExtra(Intent.EXTRA_SUBJECT, "${truck.brand} ${truck.model} - JAY MATAJI TRUCK BUY SELL")
                            putExtra(Intent.EXTRA_TEXT, shareText)
                        }
                        context.startActivity(Intent.createChooser(intent, "Share Truck"))
                    }) {
                        Icon(Icons.Default.Share, null); Spacer(Modifier.width(3.dp)); Text("SHARE")
                    }
                }
            }
        }
    }
}

@Composable
fun Detail(label: String, value: String) {
    Row(Modifier.fillMaxWidth().padding(vertical = 5.dp)) {
        Text(label, Modifier.weight(0.4f), fontWeight = FontWeight.SemiBold)
        Text(value, Modifier.weight(0.6f))
    }
}

@Composable
fun AdminScreen(trucks: List<Truck>, nav: NavHostController,
                update: (MutableList<Truck>) -> Unit) {
    Scaffold(
        topBar = { AppTopBar("Admin / Seller Panel", nav, true) },
        floatingActionButton = {
            FloatingActionButton(onClick = { nav.navigate("add") }) {
                Icon(Icons.Default.Add, "Add Truck")
            }
        }
    ) { pad ->
        LazyColumn(Modifier.padding(pad).padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)) {
            item {
                Text("Dashboard", fontSize = 24.sp, fontWeight = FontWeight.Bold)
                Text("Total: ${trucks.size}   Available: ${trucks.count { !it.sold }}   Sold: ${trucks.count { it.sold }}")
                Spacer(Modifier.height(10.dp))
            }
            itemsIndexed(trucks) { index, t ->
                Card(Modifier.fillMaxWidth()) {
                    Row(Modifier.padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text("${t.brand} ${t.model}", fontWeight = FontWeight.Bold)
                            Text("${t.year} • ${money(t.price)} • ${if (t.sold) "SOLD" else "AVAILABLE"}")
                        }
                        IconButton(onClick = {
                            val copy = trucks.toMutableList()
                            copy[index] = t.copy(sold = !t.sold)
                            update(copy)
                        }) {
                            Icon(Icons.Default.CheckCircle, "Toggle sold")
                        }
                        IconButton(onClick = {
                            val copy = trucks.toMutableList()
                            copy.removeAt(index)
                            update(copy)
                        }) {
                            Icon(Icons.Default.Delete, "Delete")
                        }
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AddTruckScreen(nav: NavHostController, onSave: (Truck) -> Unit) {
    var brand by remember { mutableStateOf("") }
    var model by remember { mutableStateOf("") }
    var year by remember { mutableStateOf("") }
    var km by remember { mutableStateOf("") }
    var fuel by remember { mutableStateOf("Diesel") }
    var price by remember { mutableStateOf("") }
    var location by remember { mutableStateOf("") }
    var description by remember { mutableStateOf("") }
    var photos by remember { mutableStateOf(listOf<String>()) }

    val picker = rememberLauncherForActivityResult(
        ActivityResultContracts.GetMultipleContents()
    ) { uris ->
        photos = (photos + uris.map(Uri::toString)).distinct().take(10)
    }

    Scaffold(topBar = { AppTopBar("Add Truck", nav, true) }) { pad ->
        LazyColumn(Modifier.padding(pad).padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)) {
            item {
                Button(onClick = { picker.launch("image/*") },
                    Modifier.fillMaxWidth()) {
                    Icon(Icons.Default.AddPhotoAlternate, null)
                    Spacer(Modifier.width(6.dp))
                    Text("Upload Photos (${photos.size}/10)")
                }
                if (photos.isNotEmpty()) {
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        items(photos) { uri ->
                            AsyncImage(Uri.parse(uri), null,
                                Modifier.size(85.dp).clip(RoundedCornerShape(8.dp)),
                                contentScale = ContentScale.Crop)
                        }
                    }
                }
            }
            item { Field("Brand", brand) { brand = it } }
            item { Field("Model", model) { model = it } }
            item { Field("Year", year) { year = it } }
            item { Field("KM Driven", km) { km = it } }
            item { Field("Fuel", fuel) { fuel = it } }
            item { Field("Price (₹)", price) { price = it } }
            item { Field("Location", location) { location = it } }
            item {
                OutlinedTextField(description, { description = it },
                    Modifier.fillMaxWidth().height(120.dp),
                    label = { Text("Description") })
            }
            item {
                Button(
                    onClick = {
                        val p = price.filter(Char::isDigit).toLongOrNull() ?: 0
                        if (brand.isNotBlank() && model.isNotBlank() && p > 0) {
                            onSave(Truck(0, brand, model, year, km, fuel, p,
                                location, description, photos))
                        }
                    },
                    Modifier.fillMaxWidth()
                ) { Text("SAVE TRUCK") }
            }
        }
    }
}

@Composable
fun Field(label: String, value: String, onValue: (String) -> Unit) {
    OutlinedTextField(value, onValue, Modifier.fillMaxWidth(), label = { Text(label) })
}
